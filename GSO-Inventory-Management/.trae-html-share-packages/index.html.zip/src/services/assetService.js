export function validateAsset(a){if(!a.propertyNo?.trim())throw Error('Property number is required');if(!a.description?.trim())throw Error('Description is required');if(Number(a.quantity)<1)throw Error('Quantity must be at least one');return true}

// Unit value rule: over ₱50,000 → Expendable, otherwise Semi-Expendable.
export const UNIT_VALUE_THRESHOLD=50000;

export function classifyByCost(cost){return Number(cost)>UNIT_VALUE_THRESHOLD?'Expendable':'Semi-Expendable'}

export function filterAssets(rows,q,classification){return rows.filter(a=>(!classification||classification==='All'||a.classification===classification)&&[a.propertyNo,a.description,a.department,a.category].join(' ').toLowerCase().includes(q.toLowerCase()))}

export function sortAssets(rows,key='propertyNo',dir='asc'){return[...rows].sort((a,b)=>{const x=a[key]??'',y=b[key]??'';const r=typeof x==='number'&&typeof y==='number'?x-y:String(x).localeCompare(String(y),undefined,{numeric:true,sensitivity:'base'});return dir==='desc'?-r:r})}

export function groupAssets(rows,key){const m=new Map();for(const r of rows){const g=r[key]||'Unspecified';if(!m.has(g))m.set(g,[]);m.get(g).push(r)}return[...m.entries()].sort((a,b)=>String(a[0]).localeCompare(String(b[0])))}
