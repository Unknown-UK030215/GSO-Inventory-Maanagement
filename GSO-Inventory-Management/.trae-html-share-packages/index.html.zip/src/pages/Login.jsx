import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';

import AuthFrame from '../components/common/AuthFrame';
import { useAuth } from '../context/useAuth';

export default function Login() {
    const { user, login } = useAuth();
    const location = useLocation();
    const navigate = useNavigate();
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [busy, setBusy] = useState(false);

    if (user) {
        return <AuthFrame title="Already signed in" description="Your inventory workspace is ready.">
            <button type="button" onClick={() => navigate('/', { replace: true })}>Open Dashboard</button>
        </AuthFrame>;
    }

    async function submit(event) {
        event.preventDefault();
        setError('');
        setBusy(true);

        try {
            await login(username, password);
            navigate(location.state?.from?.pathname || '/', { replace: true });
        } catch (err) {
            setError(err.message || 'Unable to sign in.');
        } finally {
            setBusy(false);
        }
    }

    return (
        <AuthFrame
            title="Welcome back"
            description="Sign in to manage the municipal property register."
        >
            <form className="auth-form" onSubmit={submit}>
                <label>
                    Username
                    <input
                        autoComplete="username"
                        autoFocus
                        value={username}
                        onChange={event => setUsername(event.target.value)}
                        required
                    />
                </label>
                <label>
                    Password
                    <input
                        type="password"
                        autoComplete="current-password"
                        value={password}
                        onChange={event => setPassword(event.target.value)}
                        required
                    />
                </label>
                {error && <p className="auth-error" role="alert">{error}</p>}
                <button type="submit" disabled={busy}>
                    {busy ? 'Signing in…' : 'Sign In'}
                </button>
            </form>
            <p className="auth-switch">
                New staff member? <Link to="/register">Register</Link>
            </p>
        </AuthFrame>
    );
}
