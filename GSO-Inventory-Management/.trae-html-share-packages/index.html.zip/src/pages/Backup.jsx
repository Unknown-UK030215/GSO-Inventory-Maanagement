import { useRef, useState } from 'react';

import PageHeader from '../components/common/PageHeader';
import { BACKUP_STORES, downloadBackup, restoreBackup, storeCount } from '../services/backupService';

export default function Backup() {
    const fileRef = useRef(null);
    const [status, setStatus] = useState({ type: '', message: '' });

    function handleDownload() {
        setStatus({ type: '', message: '' });
        try {
            const stores = downloadBackup();
            setStatus({
                type: 'success',
                message: `Backup downloaded — ${stores} data store${stores === 1 ? '' : 's'} saved to your file.`
            });
        } catch (err) {
            setStatus({ type: 'error', message: err.message });
        }
    }

    function handleFile(event) {
        const file = event.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = () => {
            const ok = window.confirm(
                'Restoring will replace the records currently on this device with the contents of the backup file. Continue?'
            );
            if (!ok) {
                if (fileRef.current) fileRef.current.value = '';
                return;
            }
            try {
                const stores = restoreBackup(String(reader.result || ''));
                setStatus({
                    type: 'success',
                    message: `Restored ${stores} data store${stores === 1 ? '' : 's'}. Reloading to apply…`
                });
                setTimeout(() => window.location.reload(), 900);
            } catch (err) {
                setStatus({ type: 'error', message: err.message });
                if (fileRef.current) fileRef.current.value = '';
            }
        };
        reader.readAsText(file);
    }

    const totalRecords = BACKUP_STORES.reduce((sum, store) => sum + storeCount(store.key), 0);

    return (
        <>
            <PageHeader
                title="Data Backup & Restore"
                description="Protect the GSO's official records. Download a copy of everything on this device, or restore it from a saved file."
            />

            <div className="cards workflow-cards">
                <article><small>Data Stores</small><strong>{BACKUP_STORES.length}</strong></article>
                <article><small>Records on this device</small><strong>{totalRecords.toLocaleString()}</strong></article>
                <article><small>Backup format</small><strong>.json</strong></article>
            </div>

            <div className="split">
                <article className="panel">
                    <h3>Download a Backup</h3>
                    <p className="result-count">
                        Saves all registers — assets, warehouse, supply, RPCI, work orders, logs,
                        accounts and settings — into one file you can keep in a safe place.
                    </p>
                    <div className="actions">
                        <button type="button" onClick={handleDownload}>Download Backup</button>
                    </div>
                </article>

                <article className="panel">
                    <h3>Restore from a Backup</h3>
                    <p className="result-count">
                        Use this on a new computer or after a reset. The records currently stored on
                        this device will be replaced by the file you choose.
                    </p>
                    <label className="file-field">
                        Backup file (.json)
                        <input ref={fileRef} type="file" accept="application/json,.json" onChange={handleFile} />
                    </label>
                </article>
            </div>

            {status.message && (
                <p className={`form-status ${status.type}`} role="status">{status.message}</p>
            )}

            <article className="panel">
                <h3>What's Included</h3>
                <div className="table-scroll">
                    <table>
                        <thead>
                            <tr><th>Data Store</th><th>Records</th></tr>
                        </thead>
                        <tbody>
                            {BACKUP_STORES.map(store => (
                                <tr key={store.key}>
                                    <td>{store.label}</td>
                                    <td>{storeCount(store.key).toLocaleString()}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </article>
        </>
    );
}
