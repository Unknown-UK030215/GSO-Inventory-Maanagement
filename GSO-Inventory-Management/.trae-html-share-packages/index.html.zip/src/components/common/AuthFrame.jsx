import LOGO from '../../assets/Elnido-Logo.png';

export default function AuthFrame({ title, description, children }) {
    return (
        <main className="auth-shell">
            <section className="auth-card">
                <img src={LOGO} alt="Municipality of El Nido logo" />
                <small>GENERAL SERVICES OFFICE · EL NIDO</small>
                <h1>{title}</h1>
                <p className="auth-description">{description}</p>
                {children}
                <p className="auth-notice">
                    Local prototype sign-in only. Account data is stored in this browser and is not server-secured.
                </p>
            </section>
        </main>
    );
}
