import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { sampleAssets } from '../data/sampleAssets';
import { useAuth } from './useAuth';

const InventoryContext = createContext(null);

// Monotonic numeric id source so a record added to one register can never
// share an id with a record in the other, even within the same millisecond.
let idCounter = Date.now();
const nextId = () => idCounter++;

export function InventoryProvider({ children }) {
    // The signed-in user is stamped on every record and activity entry so
    // administrators can see exactly what each account encoded and did.
    const { user } = useAuth();
    const actor = user?.username || 'system';
    const actorName = user?.displayName || 'System';

    // Inventory and Warehouse keep separate registers. `assets` holds the
    // inventory property records; `warehouseAssets` holds the warehouse
    // records (its own stock items plus AIR / RIS / SSMI transactions). The
    // split keeps property numbers, counts and duplicate checks scoped to a
    // single register, so registering in one never conflicts with the other.
    const [assets, setAssets] = useState(() =>
        JSON.parse(localStorage.getItem('gso-assets') || 'null') || sampleAssets
    );
    const [warehouseAssets, setWarehouseAssets] = useState(() =>
        JSON.parse(localStorage.getItem('gso-warehouse-assets') || '[]')
    );
    const [logs, setLogs] = useState(() =>
        JSON.parse(localStorage.getItem('gso-logs') || '[]')
    );

    useEffect(() => {
        localStorage.setItem('gso-assets', JSON.stringify(assets));
    }, [assets]);

    useEffect(() => {
        localStorage.setItem('gso-warehouse-assets', JSON.stringify(warehouseAssets));
    }, [warehouseAssets]);

    useEffect(() => {
        localStorage.setItem('gso-logs', JSON.stringify(logs));
    }, [logs]);

    // Combined pool for cross-form exports (e.g. SSMI pulls RIS records).
    const allAssets = useMemo(() => [...assets, ...warehouseAssets], [assets, warehouseAssets]);

    const log = (action, detail) => {
        setLogs(current => [
            {
                id: Date.now(),
                date: new Date().toLocaleString(),
                action,
                detail,
                actor,
                actorName
            },
            ...current
        ]);
    };

    // `pool` selects which register the record belongs to, so the calling
    // workspace (Inventory vs Warehouse) decides where it is stored.
    const addAsset = (asset, pool = 'inventory') => {
        const record = {
            ...asset,
            id: nextId(),
            registeredBy: actor,
            registeredByName: actorName
        };
        if (pool === 'warehouse') {
            setWarehouseAssets(current => [record, ...current]);
        } else {
            setAssets(current => [record, ...current]);
        }
        log('Created asset', record.propertyNo || record.risNo || record.airNo || record.ssmiMonth || '');
    };

    const updateAsset = (id, changes, activity) => {
        // Search both pools; the record lives in exactly one of them.
        setAssets(current => current.map(asset =>
            asset.id === id ? { ...asset, ...changes } : asset
        ));
        setWarehouseAssets(current => current.map(asset =>
            asset.id === id ? { ...asset, ...changes } : asset
        ));
        log(activity?.action || 'Updated asset', activity?.detail || String(id));
    };

    const deleteAsset = id => {
        setAssets(current => current.filter(asset => asset.id !== id));
        setWarehouseAssets(current => current.filter(asset => asset.id !== id));
        log('Deleted asset', String(id));
    };

    return (
        <InventoryContext.Provider value={{
            assets,
            warehouseAssets,
            allAssets,
            logs,
            addAsset,
            updateAsset,
            deleteAsset,
            log
        }}>
            {children}
        </InventoryContext.Provider>
    );
}

// Shared hook export is intentionally kept beside the inventory provider.
// eslint-disable-next-line react-refresh/only-export-components
export const useInventory = () => useContext(InventoryContext);
