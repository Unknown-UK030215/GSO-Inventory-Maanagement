import { useState } from 'react';

import AuthContext from './authContextBase';
const USERS_KEY = 'gso-local-users';
const SESSION_KEY = 'gso-auth-user';
const DEFAULT_USERNAME = 'Staff';
const DEFAULT_PASSWORD = 'Staff1323';

function readUsers() {
    try {
        const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
        return Array.isArray(users) ? users : [];
    } catch {
        return [];
    }
}

function readSession() {
    try {
        const user = JSON.parse(localStorage.getItem(SESSION_KEY) || 'null');
        return user?.username ? user : null;
    } catch {
        return null;
    }
}

async function hashPassword(password) {
    if (!globalThis.crypto?.subtle) {
        throw new Error('Password hashing is unavailable in this browser. Open the app on localhost or HTTPS.');
    }

    const bytes = new TextEncoder().encode(password);
    const digest = await globalThis.crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
}

export function AuthProvider({ children }) {
    const [user, setUser] = useState(readSession);

    function startSession(account) {
        const session = {
            username: account.username,
            displayName: account.displayName || account.username
        };
        localStorage.setItem(SESSION_KEY, JSON.stringify(session));
        setUser(session);
        return session;
    }

    async function login(username, password) {
        const normalizedUsername = username.trim().toLowerCase();

        if (normalizedUsername === DEFAULT_USERNAME.toLowerCase() && password === DEFAULT_PASSWORD) {
            return startSession({ username: DEFAULT_USERNAME, displayName: 'Inventory Staff' });
        }

        const account = readUsers().find(item =>
            typeof item.username === 'string' &&
            item.username.toLowerCase() === normalizedUsername
        );
        if (!account || account.passwordHash !== await hashPassword(password)) {
            throw new Error('Username or password is incorrect.');
        }

        return startSession(account);
    }

    async function register({ displayName, username, password }) {
        const cleanName = displayName.trim();
        const cleanUsername = username.trim();
        const normalizedUsername = cleanUsername.toLowerCase();

        if (!cleanName || cleanUsername.length < 3) {
            throw new Error('Enter a name and a username with at least 3 characters.');
        }
        if (normalizedUsername === DEFAULT_USERNAME.toLowerCase() ||
            readUsers().some(item =>
                typeof item.username === 'string' &&
                item.username.toLowerCase() === normalizedUsername
            )) {
            throw new Error('That username is already registered.');
        }
        if (password.length < 8) {
            throw new Error('Choose a password with at least 8 characters.');
        }

        const account = {
            username: cleanUsername,
            displayName: cleanName,
            passwordHash: await hashPassword(password)
        };
        localStorage.setItem(USERS_KEY, JSON.stringify([...readUsers(), account]));
        return startSession(account);
    }

    function logout() {
        localStorage.removeItem(SESSION_KEY);
        setUser(null);
    }

    return (
        <AuthContext.Provider value={{ user, login, register, logout }}>
            {children}
        </AuthContext.Provider>
    );
}
